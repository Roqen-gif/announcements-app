import { Request, Response } from 'express';
import * as service from '../services/announcements.service';
import { AnnouncementCreateSchema } from '../validators/announcement.validator';


export async function list(req: Request, res: Response) {
const { page = 1, limit = 10, search } = req.query;
const result = await service.listAnnouncements({ page: Number(page), limit: Number(limit), search });
return res.json({ data: result.data.map(formatAnnouncement), meta: { page: Number(page), limit: Number(limit), total: result.total } });
}


export async function getOne(req: Request, res: Response) {
const { id } = req.params;
const ann = await service.getAnnouncement(id);
if (!ann) return res.status(404).json({ error: 'Not found' });
return res.json(formatAnnouncement(ann));
}


export async function create(req: Request, res: Response) {
const parse = AnnouncementCreateSchema.safeParse(req.body);
if (!parse.success) return res.status(400).json({ error: parse.error.errors });
const created = await service.createAnnouncement(parse.data);
return res.status(201).json(formatAnnouncement(created));
}


export async function update(req: Request, res: Response) {
const { id } = req.params;
const parse = AnnouncementCreateSchema.safeParse(req.body);
if (!parse.success) return res.status(400).json({ error: parse.error.errors });
const updated = await service.updateAnnouncement(Number(id), parse.data);
return res.json(formatAnnouncement(updated));
}


export async function remove(req: Request, res: Response) {
const { id } = req.params;
await service.deleteAnnouncement(Number(id));
return res.status(204).send();
}


function formatAnnouncement(a: any) {
return {
id: a.id,
title: a.title,
content: a.content,
publicationDate: a.publicationDate.toISOString(),
lastUpdate: a.lastUpdate.toISOString(),
categories: Array.isArray(a.categories) ? a.categories.map((c: any) => c.name) : [],
linkSlug: a.linkSlug
};
}