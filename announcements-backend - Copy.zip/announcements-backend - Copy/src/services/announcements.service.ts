import prisma from '../prismaClient';
: { id: byId };


const ann = await prisma.announcement.findFirst({
where,
include: { categories: true }
});
return ann;
}


export async function createAnnouncement(payload: any) {
const { title, content, publicationDate, categories } = payload;
const slug = makeSlug(title);


// ensure categories exist or create
const categoryConnect = await Promise.all(
categories.map(async (name: string) => {
const existing = await prisma.category.findUnique({ where: { name } });
if (existing) return { id: existing.id };
const created = await prisma.category.create({ data: { name } });
return { id: created.id };
})
);


const pubDate = parsePublicationDate(publicationDate);


const ann = await prisma.announcement.create({
data: {
title,
content,
publicationDate: pubDate,
linkSlug: slug,
categories: { connect: categoryConnect }
},
include: { categories: true }
});


return ann;
}


export async function updateAnnouncement(id: number, payload: any) {
const { title, content, publicationDate, categories } = payload;
const slug = makeSlug(title);
const pubDate = parsePublicationDate(publicationDate);


// same category upsert logic
const categoryConnect = await Promise.all(
categories.map(async (name: string) => {
const existing = await prisma.category.findUnique({ where: { name } });
if (existing) return { id: existing.id };
const created = await prisma.category.create({ data: { name } });
return { id: created.id };
})
);


const ann = await prisma.announcement.update({
where: { id },
data: {
title,
content,
publicationDate: pubDate,
linkSlug: slug,
categories: { set: categoryConnect }
},
include: { categories: true }
});


return ann;
}


export async function deleteAnnouncement(id: number) {
await prisma.announcement.delete({ where: { id } });
}


function parsePublicationDate(input: string) {
// input format: MM/DD/YYYY HH:mm
const [datePart, timePart] = input.split(' ');
const [month, day, year] = datePart.split('/').map(Number);
const [hour, minute] = timePart.split(':').map(Number);
// construct JS date in local timezone and convert to Date object
return new Date(year, month - 1, day, hour, minute);
}